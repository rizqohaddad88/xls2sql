<?php
session_start();
ob_start("ob_gzhandler");
$_modeon=1; //true
require_once "config/configurasi-php-mysql.php";
require_once "config/function-system.php";
require_once "config/excel_reader.php";
koneksi_();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>XLS2SQL</title>
<link rel="shortcut icon" href="images/loading.gif" />
</head>
<style>
a{text-decoration:underline; cursor:pointer;}
</style>
<script language="javascript" type="text/javascript" src="js/jquery.js"></script>
<script language="javascript" type="text/javascript">

$(document).ready(function(){})

function sinkronkan(idtabel){
	if(confirm("Sinkronisasi Data akan dilakukan???")){
		$("#loading").show();
		$.ajax({
			type:"POST",
			url:"sinkronisasi-xls2sql.php",
			data:"idtabel="+idtabel+"",
			success:function(){
				$("#loading").hide();
				window.location="./";
			}
		})
	}
}

function getxls(idkat){
	if(confirm("Download Data???")){
		window.open("data/cetak-xls.php?idkat="+idkat+"","data"+idkat+"","scrollbars=yes, menubar=yes");
	}
}
</script>
<body>
<h1>XLS2SQL</h1>
<form method="post" enctype="multipart/form-data">
Import data from excel 2003
<span id="btn_loadimport">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Silakan Pilih File Excel: 
	<input name="fileexcelnya" id="fileexcelnya" type="file">
	<input name="upload" id="upload" type="submit" value="Import">
</span>
<?php
if($_POST){

$jmlnmfile	= strlen($_FILES['fileexcelnya']['name']) - 4;
$mikros		= date("dmY_His");
$nmfile		= substr(str_replace(" ","_",$_FILES['fileexcelnya']['name']),0,$jmlnmfile)."_".$mikros;
$data 		= new Spreadsheet_Excel_Reader($_FILES['fileexcelnya']['tmp_name']);
$baris 		= $data->rowcount($sheet_index=0);

	$buattable	= mysql_query("
							CREATE TABLE $nmfile (
							id double NOT NULL AUTO_INCREMENT,
							nama varchar(150) DEFAULT NULL,
							alamat varchar(255) DEFAULT NULL,
							tlp varchar(255) DEFAULT NULL,
							email varchar(50) DEFAULT NULL,
							PRIMARY KEY (id)
							)
							");
							
	$addmasterdata= mysql_query("insert into table_xls_sql values ('','$nmfile','0')");

$ok 	= 0;
$xok 	= 0;
for ($i=2; $i<=$baris; $i++)
{
  $nama 	= addslashes($data->val($i, 2));
  $alamat	= addslashes($data->val($i, 3));
  $tlp		= addslashes($data->val($i, 4));
  $email	= addslashes($data->val($i, 5));

  if(!empty($nama)){
	  $query = "INSERT INTO $nmfile VALUES ('', '$nama', '$alamat', '$tlp', '$email')";
	  $hasil = mysql_query($query);
	  if($hasil){$ok++;}else{$xok++;}
  }	 // end if 
} //end for

	$updatemasterdata= mysql_query("update table_xls_sql set jml = '$ok' where nm = '$nmfile'");
	
echo "<span id='pesan_error'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Proses import data selesai.. Sukses: $ok, Gagal: $xok </span>";


} //end post
?>
</form>
<a href="data/sampel.xls"> Download format data excel</a><br />
<br />
Catatan:
<div>- Nama file excel hanya diperbolehkan menggunakan huruf (alphabet Aa-Zz)</div>
<br />
<a href="./">Refresh Data</a> <span id="loading" style="display:none;"><img src="images/loading.gif"> Loading data... Please wait........</span>
<br />
<ul>
<?php
$querytable	= mysql_query("select * from table_xls_sql");
$jmldata	= mysql_num_rows($querytable);
while($table = mysql_fetch_array($querytable)){
	echo "<li>$table[nm] -> ".get_jml_tablexls_sql($table[nm])." Data (<a onclick=\"sinkronkan('$table[idtable]')\">Sinkronisasikan Tabel</a>)</li>";
}
?>
</ul>
<br />
<div><?php echo (get_jmlmasterdata() > 0) ? "<a onclick=\"getxls('1')\">Download Data</a>" : "";?></div>
</body>
</html>
