/*
SQLyog Enterprise - MySQL GUI v8.05 
MySQL - 5.5.27-log : Database - repo_xls2sql
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `masterdata` */

CREATE TABLE `masterdata` (
  `id` double NOT NULL AUTO_INCREMENT,
  `nama` varchar(150) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `tlp` varchar(150) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `table_xls_sql` */

CREATE TABLE `table_xls_sql` (
  `idtable` double NOT NULL AUTO_INCREMENT,
  `nm` varchar(255) DEFAULT NULL,
  `jml` double DEFAULT NULL,
  PRIMARY KEY (`idtable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;