<?php
session_start();
ob_start("ob_gzhandler");
$_modeon=1; //true
require_once "config/configurasi-php-mysql.php";
require_once "config/function-system.php";
require_once "config/excel_reader.php";
koneksi_();

$idtabel	= $_POST[idtabel];
$nmtable	= get_table($idtabel,"nm");

$query		= mysql_query("select * from $nmtable order by id asc");
while($data	= mysql_fetch_array($query)){
	$add	= mysql_query(" insert into masterdata values (
							'',
							'".addslashes($data[nama])."',
							'".addslashes($data[alamat])."',
							'".addslashes($data[tlp])."',
							'".addslashes($data[email])."'
							)");
	$del	= mysql_query("delete from $nmtable where id='$data[id]'");
}

$null	= mysql_query("delete from table_xls_sql where idtable = '$idtabel'");
$del	= mysql_query("drop table $nmtable");
?>