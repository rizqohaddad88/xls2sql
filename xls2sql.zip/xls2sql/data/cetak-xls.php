<?php
$_modeon=1; //true
require_once "../config/configurasi-php-mysql.php";
require_once "../config/function-system.php";
require_once "../config/excel_reader.php";
koneksi_();

$idkat	= $_GET[idkat];

switch($idkat){
case 1	: require_once "cetak-xls-data.php"; break;
}

?>