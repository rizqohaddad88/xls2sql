<?php
function xlsBOF() {
echo pack("ssssss", 0x809, 0x8, 0x0, 0x10, 0x0, 0x0);
return;
}

function xlsEOF() {
echo pack("ss", 0x0A, 0x00);
return;
}

function xlsWriteNumber($Row, $Col, $Value) {
echo pack("sssss", 0x203, 14, $Row, $Col, 0x0);
echo pack("d", $Value);
return;
}

function xlsWriteLabel($Row, $Col, $Value ) {
$L = strlen($Value);
echo pack("ssssss", 0x204, 8 + $L, $Row, $Col, 0x0, $L);
echo $Value;
return;
}

$namaFile = "DATA.xls";

header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
header("Content-Disposition: attachment; filename=".$namaFile."");
header("Content-Transfer-Encoding: binary ");
xlsBOF();

xlsWriteLabel(0,1,"");
xlsWriteLabel(1,1,"");
xlsWriteLabel(2,1,"MASTER DATA");

xlsWriteLabel(3,0,"NO");
xlsWriteLabel(3,1,"NAMA");
xlsWriteLabel(3,2,"ALAMAT");
xlsWriteLabel(3,3,"TLP");
xlsWriteLabel(3,4,"EMAIL");

$no=1;
$noBarisCell = 4;
$querydata		= mysql_query("SELECT * FROM masterdata order by id asc");
while($row		= mysql_fetch_array($querydata)){

xlsWriteNumber($noBarisCell,0,"$no");
xlsWriteLabel($noBarisCell,1,$row[nama]);
xlsWriteLabel($noBarisCell,2,$row[alamat]);
xlsWriteLabel($noBarisCell,3,$row[tlp]);
xlsWriteLabel($noBarisCell,4,$row[email]);
$noBarisCell++;
$no++;
}

xlsEOF();
exit();
?>