<?php
######################################################
# Created by Rizqo Haddad - rizqohaddad88@gmail.com  #
# http://devsoft88.blogspot.com/  					 # 
######################################################
if(empty($_modeon)){exit();}
$hostname			= "localhost";
$dbusername			= "admin";
$dbpassword			= "admin123";
$dbname				= "repo_xls2sql";
date_default_timezone_set("Asia/Jakarta");
foreach($_POST as $key => $val){$_POST[$key] = str_replace("'","",$val);}
foreach($_GET as $key => $val){$_GET[$key] = str_replace("'","",$val);}
?>