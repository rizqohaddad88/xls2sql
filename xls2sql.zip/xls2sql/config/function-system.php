<?php
######################################################
# Created by Rizqo Haddad - rizqohaddad88@gmail.com  #
# http://devsoft88.blogspot.com/  					 # 
######################################################
if(empty($_modeon)){exit();}

function koneksi_(){
	global $hostname,$dbusername,$dbpassword,$dbname;
	$lakukan_koneksi	=@mysql_connect($hostname,$dbusername,$dbpassword);
	$ke_mysql			=@mysql_select_db($dbname,$lakukan_koneksi);
}

function get_jml_tablexls_sql($nmtabel){
	$query	= mysql_query("select * from $nmtabel");
	$jml	= mysql_num_rows($query);
	return $jml;
}

function get_table($idtable,$var){
	$query	= mysql_query("select * from table_xls_sql where idtable = '$idtable'");
	$data	= mysql_fetch_array($query);
	return $data[$var];
}

function get_jmlmasterdata(){
	$query	= mysql_query("select count(id) as jml from masterdata");
	$data	= mysql_fetch_array($query);
	return $data[jml];
}
?>